/********************************************************************************
** Form generated from reading UI file 'ware.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WARE_H
#define UI_WARE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Ware
{
public:
    QWidget *widgetWaveForm;

    void setupUi(QWidget *Ware)
    {
        if (Ware->objectName().isEmpty())
            Ware->setObjectName(QString::fromUtf8("Ware"));
        Ware->resize(1100, 650);
        Ware->setMinimumSize(QSize(1100, 650));
        Ware->setMaximumSize(QSize(1100, 650));
        widgetWaveForm = new QWidget(Ware);
        widgetWaveForm->setObjectName(QString::fromUtf8("widgetWaveForm"));
        widgetWaveForm->setGeometry(QRect(4, 4, 1091, 541));

        retranslateUi(Ware);

        QMetaObject::connectSlotsByName(Ware);
    } // setupUi

    void retranslateUi(QWidget *Ware)
    {
        Ware->setWindowTitle(QApplication::translate("Ware", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Ware: public Ui_Ware {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WARE_H
