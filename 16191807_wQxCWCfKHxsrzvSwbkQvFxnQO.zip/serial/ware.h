#ifndef WARE_H
#define WARE_H

#include <QWidget>
#include <QtCharts/QChartView>//显示图表
#include <QtCharts/QLineSeries>//线系列
#include <QDoubleSpinBox>
#include <QGridLayout>
#include <QTimer>
#include <QtCharts/QSplineSeries>
#include <QtCharts/QValueAxis>

#include <QWidget>
#include <QChart>
#include <QLineSeries>
#include <QVector>
#include <QTimer>

#include "chartview.h"
#include "callout.h"
#include "qcheckbox.h"

QT_CHARTS_USE_NAMESPACE

namespace Ui {
class Ware;
}

class Ware : public QWidget
{
    Q_OBJECT

public:
    //帧数据
    uint8_t      head;
    uint8_t      address;
    uint8_t      length;
    int16_t      ware1; //波形1的新数据
    int16_t      ware2; //波形2的新数据
    uint8_t      check;
    bool         isValid;

    explicit Ware(QWidget *parent = nullptr);

    void serial_updata_data(bool isUpdate);

    ~Ware();

private slots:      //槽函数
    void timerSlot();
    void tipSlot(QPointF position, bool isHovering);

    void on_startOrStopBt_clicked();

    void on_resetBt_clicked();

    void on_themeChooseQcb_currentIndexChanged();

    void on_clearBt_clicked();

    void on_ware1Cbox_stateChanged();

    void on_ware2Cbox_stateChanged();

    void set_num_on_qcheckBox(QCheckBox *lbl, QString strS, double num);

private:
    void wheelEvent(QWheelEvent *event);

    void init_UI();
    void init_chart();
    void init_slot();

    void update_data();

    Ui::Ware    *ui;

    ChartView   *chartView;
    QChart      *chart;
    Callout     *tip;
    QLineSeries *series;  //两条波形
    QTimer      *timer;
    QValueAxis   m_axis;

    uint16_t     count;
    uint16_t     POINTNUM;

    double       minY,maxY;
    bool         isStopping;
    bool         isShowWare1;
    bool         isShowWare2;
    bool         isUpDate;      //是否需要更新数据，即是否有新数据读入
};

#endif // WARE_H
