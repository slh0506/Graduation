#include "widget.h"
#include "ui_widget.h"
#include "QSerialPortInfo"
#include <QString>
#include "qmessagebox.h"
#include "ware.h"

#include <qvalidator.h>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    wa(new Ware),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QStringList serialNamePort;
    QValidator *validator=new QIntValidator(0,99999,this);   //设置输入范围

    serialPort = new QSerialPort(this);

    connect(serialPort, SIGNAL(readyRead()), this, SLOT(serialPortReadyRead_Slot()));//把接收数据信号与接收槽函数关联
    connect(&timer,SIGNAL(timeout()),this,SLOT(on_sendBt_clicked())); //把定时器溢出信号与串口发送槽函数关联
    //第一个参数为串口的信息类，用于存放串口信息；第二个参数代表自动搜索当前的可用串口
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        serialNamePort << info.portName();  //把返回的参数加给serialNamePort对象
    }
    ui->serialCb->addItems(serialNamePort); //把串口信息显示到ui界面

    ui->timeSendQl->setValidator(validator);//设置定时器输入框可输入范围
}

Widget::~Widget()
{
    delete ui;
}

void Widget::set_num_on_label(QLabel *lbl, QString strS, long num)
{
    QString strN;
    strN.sprintf("%7ld",num);
    QString str = strS + strN;
    lbl -> setText(str);
}

/************************打开按钮槽函数************************/
void Widget::on_openBt_clicked()
{
    QSerialPort::BaudRate baundRate;    //波特率
    QSerialPort::DataBits dataBits;     //数据位
    QSerialPort::StopBits stopBits;     //停止位
    QSerialPort::Parity   checkBits;    //校验位

    //根据选择的波特率进行参数配置
    if(ui->baundrateCb->currentText() == "4800")
    {
        baundRate = QSerialPort::Baud4800;
    }
    else if (ui->baundrateCb->currentText() == "9600")
    {
        baundRate = QSerialPort::Baud9600;
    }
    else if (ui->baundrateCb->currentText() == "115200")
    {
        baundRate = QSerialPort::Baud115200;
    }
    else
    {
        baundRate = QSerialPort::Baud115200;    //默认设置，防止出现警告
    }

    //根据选择的数据位进行参数配置
    if(ui->dataCb->currentText() == "5")
    {
        dataBits = QSerialPort::Data5;
    }
    else if (ui->dataCb->currentText() == "6")
    {
        dataBits = QSerialPort::Data6;
    }
    else if (ui->dataCb->currentText() == "7")
    {
        dataBits = QSerialPort::Data7;
    }
    else if (ui->dataCb->currentText() == "8")
    {
        dataBits = QSerialPort::Data8;
    }
    else
    {
        dataBits = QSerialPort::Data8;  //默认设置，防止出现警告
    }

    //根据选择的停止位进行参数配置
    if(ui->stopCb->currentText() == "1")
    {
        stopBits = QSerialPort::OneStop;
    }
    else if (ui->stopCb->currentText() == "1.5")
    {
        stopBits = QSerialPort::OneAndHalfStop;
    }
    else if (ui->stopCb->currentText() == "2")
    {
        stopBits = QSerialPort::TwoStop;
    }
    else
    {
       stopBits = QSerialPort::OneStop; //默认设置，防止出现警告
    }

    //根据选择的校验位进行参数配置
    if(ui->checkCb->currentText() == "无")
    {
        checkBits = QSerialPort::NoParity;
    }
    else
    {
        checkBits = QSerialPort::NoParity;  //默认设置，防止出现警告
    }

    serialPort->setPortName(ui->serialCb->currentText());   //设置串口号
    serialPort->setBaudRate(baundRate);     //设置波特率
    serialPort->setDataBits(dataBits);      //设置数据位
    serialPort->setStopBits(stopBits);      //设置停止位
    serialPort->setParity(checkBits);       //设置校验位

    //判断串口初始化是否成功
    if(serialPort->open(QIODevice::ReadWrite) == true)
    {
        ui->plainTextEdit->appendPlainText("串口连接成功!");
        ui->closeBt->setEnabled(true);     //使能关闭按钮
        ui->sendBt->setEnabled(true);      //使能发送按钮
        ui->wareBt->setEnabled(true);      //使能波形按钮
        ui->openBt->setDisabled(true);     //失能打开按钮

        isSerialConnect = true;
    }
    else
    {
        ui->plainTextEdit->appendPlainText("串口连接失败!");
    }
}

/************************关闭按钮槽函数************************/
void Widget::on_closeBt_clicked()
{
    serialPort->close();
    ui->openBt->setEnabled(true);     //使能打开按钮
    ui->closeBt->setDisabled(true);   //失能关闭按钮
    ui->sendBt->setDisabled(true);    //失能发送按钮
    ui->wareBt->setDisabled(true);    //失能波形按钮
    isSerialConnect=false;
    ui->plainTextEdit->appendPlainText("串口已关闭!");
}

/************************发送数据按钮槽函数************************/
void Widget::on_sendBt_clicked()
{
    //将发送栏的数据输出
    long long a=0;
    //字符串形式
    if(ui->is16SendQch->checkState() == false)
    {
        a=serialPort->write(ui->lineEdit->text().toLocal8Bit().data());
    }
    else    //16进制发送（将16进制转换成Ascll码对应的字符发送）
    {
        a=serialPort->write(QByteArray::fromHex(ui->lineEdit->text().toUtf8()).data()); //16进制数据解码后发送
    }
    //如果发送成功，a获取发送的字节长度，发送失败则返回-1；

    if(a > 0)
    {
        sendNum += a;
        set_num_on_label(ui->sendLbl,"S:", sendNum);
    }
}

/************************接收数据槽函数，需要手动关联************************/
void Widget::serialPortReadyRead_Slot()
{
    QString buf;
    QByteArray recBuf;
    int bufNum;
    uint8_t checkNum=0;   //计算校验码

    //读取所有字节
    recBuf=serialPort->readAll();
    //接收字节计数
    recvNum += recBuf.size();

    if(ui->is16RecvQch->checkState() == false)  //不使用16进制接收
    {
        buf = QString(recBuf);
    }
    else
    {
        buf = QString(recBuf).toUtf8().toHex();     //转成16进制

        //每个16进制数据之间用空格分隔
        bufNum = buf.length();
        while(bufNum-2 > 0)
        {
            bufNum = bufNum - 2;
            buf.insert(bufNum," ");
        }
    }
    ui->plainTextEdit->insertPlainText(buf);         //把接收到的数据显示到接收栏上
    ui->plainTextEdit->moveCursor(QTextCursor::End); //光标设置，确保滚轮滚动

    //状态栏显示计数值
    set_num_on_label(ui->recvLbl, "R:", recvNum);

    if(wa->isHidden() == false &&                   //界面打开后才进行波形显示
       static_cast<uint8_t>(recBuf[0]) == 0xAA &&   //同时要保证帧头和地址正确
       static_cast<uint8_t>(recBuf[1]) == 0xCC)
    {
        //计算校验位
        for(uint8_t i=3;i<7;i++)
            checkNum += recBuf[i];

        if(checkNum == static_cast<uint8_t>(recBuf[7])) //校验位正确
        {
            //数据类型转换并转移到Ware的属性中
            wa->head    = static_cast<uint8_t>(recBuf[0]);
            wa->address = static_cast<uint8_t>(recBuf[1]);
            wa->length  = static_cast<uint8_t>(recBuf[2]);
            wa->ware1   = static_cast<uint8_t>(recBuf[3])*256+static_cast<uint8_t>(recBuf[4]);
            wa->ware2   = static_cast<uint8_t>(recBuf[5])*256+static_cast<uint8_t>(recBuf[6]);
            wa->check   = static_cast<uint8_t>(recBuf[7]);
            wa->isValid = true;
        }
        else
        {
            wa->isValid = false;
        }
        //wa->serial_updata_data(wa->isValid);   //波形绘制
    }
}

/************************清空按钮点击槽函数************************/
void Widget::on_clearBt_clicked()
{
    ui->plainTextEdit->clear();  //清空接收框

    //清空计数
    recvNum = 0;
    sendNum = 0;
    set_num_on_label(ui->recvLbl, "R:", recvNum);
    set_num_on_label(ui->sendLbl, "S:", sendNum);
}

/************************波形显示按钮点击槽函数************************/
void Widget::on_wareBt_clicked()
{
    wa->setGeometry(this->geometry());      //获取当前窗口的xy数据
    wa->setWindowTitle("Ware");             //更改名称
    wa->show();                             //显示界面
}

/************************串口搜索按钮点击槽函数************************/
void Widget::on_searchBt_clicked()
{
    ui->serialCb->clear();  //清空

    //重新搜索
    QStringList serialNamePort;

    serialPort = new QSerialPort(this);

    connect(serialPort, SIGNAL(readyRead()), this, SLOT(serialPortReadyRead_Slot()));//关联信号槽

    //第一个参数为串口的信息类，用于存放串口信息；第二个参数代表自动搜索当前的可用串口
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        serialNamePort << info.portName();  //把返回的参数加给serialNamePort对象
    }
    ui->serialCb->addItems(serialNamePort); //把串口信息显示到ui界面
}

/************************字符串/16进制发送切换槽函数************************/
void Widget::on_is16SendQch_stateChanged()
{
    QString str;
    int strNum;

    if(ui->is16SendQch->checkState() == false)  //转成字符串
    {
        ui->lineEdit->setText(QByteArray::fromHex(ui->lineEdit->text().toUtf8()).data());   //解码16进制
    }
    else    //转成16进制
    {
        str=ui->lineEdit->text().toUtf8().toHex().data();

        //每个16进制数据之间用空格分隔
        strNum = str.length();
        while(strNum-2 > 0)
        {
            strNum = strNum - 2;
            str.insert(strNum," ");
        }

        ui->lineEdit->setText(str);
    }
}

/************************字符串/16进制接收切换槽函数************************/
void Widget::on_is16RecvQch_stateChanged()
{
    //暂不使用
}

/************************定时发送开始/关闭槽函数************************/
void Widget::on_timeSendQch_stateChanged()
{
    long counter;
    if(ui->timeSendQch->checkState() == false)  //定时发送关闭
    {
        timer.stop();       //关闭定时器
    }
    else    //定时发送打开
    {
        counter = (ui->timeSendQl->text()).toLong();    //转换成长整型
        if(counter>0 && ui->lineEdit->text() != "" && isSerialConnect == true)     //定时时间需大于0ms且发送栏须有字符,否则关闭
        {
            timer.start(counter);   //打开定时器，单位ms
        }
        else
        {
            timer.stop();   //关闭定时器
        }
    }
}
