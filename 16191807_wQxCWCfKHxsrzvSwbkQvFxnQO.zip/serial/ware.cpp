#include "ware.h"
#include "ui_ware.h"
#include "widget.h"

#include "QTime"
#include "QDebug"
#include "qmath.h"
#include "QValueAxis"
#include "QDateTimeAxis"
#include "QRandomGenerator"

Ware::Ware(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Ware),
    chart(new QChart),
    tip(nullptr),   //nullptr为空指针
    timer(new QTimer),
    count(0),
    POINTNUM(200),
    minY(-5),
    maxY(5),
    isStopping(false),
    isShowWare1(true),
    isShowWare2(true),
    isUpDate(false)
{
    ui->setupUi(this);

    init_UI();       //初始化界面

    //timer->setInterval(50); //定时50ms
    //timer->start();

    init_slot();     //关联槽函数
}

void Ware::init_UI()
{
    init_chart();
}

/************************初始化图表函数************************/
void Ware::init_chart()
{
    series = new QLineSeries[2];       //声明序列

    chart->setTheme(QChart::ChartThemeLight); //设置系统主题
    chart->setTitleFont(QFont("微软雅黑",15, QFont::Black, false)); //设置标题字体,字型、大小、粗细、是否斜体
    chart->setTitle("电压监测波形图");          //设置标题
    series[0].setName("波形1");                //图例设置
    series[1].setName("波形2");
    chart->legend()->show();                  //显示图例

    //波形1
    QPen pen1(Qt::darkRed);              //设置画笔颜色
    pen1.setWidth(2);                    //设置线宽
    series[0].setPen(pen1);              //设置画笔

    //波形2
    QPen pen2(Qt::darkBlue);             //设置画笔颜色
    pen2.setWidth(2);                    //设置线宽
    series[1].setPen(pen2);              //设置画笔

    chart->addSeries(&series[0]);       //把数据集1加入图表
    chart->addSeries(&series[1]);       //把数据集2加入图表

    chart->setAnimationOptions(QChart::NoAnimation);    //默认设置网格和序列都没有动画效果
//    series->setUseOpenGL(true);     //OpenQL加速开启,开启后光标数据无法显示

    /* 设置XY轴坐标轴范围*/
    chart->createDefaultAxes();               //根据序列设置图表默认的坐标轴
    m_axis.setTickCount(POINTNUM/20+1);       //设置刻度线数量，使用这个会导致复位按键出现bug
    chart->setAxisX(&m_axis,&series[0]);
    chart->setAxisX(&m_axis,&series[1]);

    chart->axisY()->setRange(minY, maxY);     //设置Y轴范围
    chart->axisX()->setRange(0, POINTNUM);    //设置X轴范围

    /* 设置XY轴坐标名称和字体:we微软雅黑、10号、斜体 */
    chart->axisX()->setTitleFont(QFont("Microsoft YaHei", 10, QFont::Normal, true));
    chart->axisY()->setTitleFont(QFont("Microsoft YaHei", 10, QFont::Normal, true));
    chart->axisX()->setTitleText("t/ms");
    chart->axisY()->setTitleText("Vol/mV");

    /* 设置XY轴网格是否可视 */
    chart->axisX()->setGridLineVisible(true);
    chart->axisY()->setGridLineVisible(true);

    chartView = new ChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);      //反走样功能，调用反锯齿功能

    /* 把图表加入布局 */
    ui->wareQbl->addWidget(chartView);
}

/************************关联信号槽************************/
void Ware::init_slot()
{
    //connect(timer, SIGNAL(timeout()), this, SLOT(timerSlot())); //定时器溢出信号
    connect(&series[0], SIGNAL(hovered(QPointF, bool)), this, SLOT(tipSlot(QPointF,bool))); //波形1光标手动关联
    connect(&series[1], SIGNAL(hovered(QPointF, bool)), this, SLOT(tipSlot(QPointF,bool))); //波形2光标手动关联
}

/************************定时器溢出槽函数************************/
void Ware::timerSlot()
{
    if (QObject::sender() == timer)     //确认是定时器出发了信号
    {
        update_data();
    }
}

//设置波形选择框数据
void Ware::set_num_on_qcheckBox(QCheckBox *QcheckBox, QString strS, double num)
{
    QString strN;
    strN.sprintf("%6.2lf",num);
    QString str = strS + strN;
    QcheckBox -> setText(str);
}

//串口数据更新
void Ware::serial_updata_data(bool isUpdate)
{
    QString strN;
    //数据显示
    if(isUpdate == true)
    {
        strN.sprintf("%X",head);
        ui->headQl->setText(strN);
        strN.sprintf("%X",address);
        ui->addressQl->setText(strN);
        strN.sprintf("%X",length);
        ui->lengthQl->setText(strN);
        strN.sprintf("%X",ware1);
        ui->data1Ql->setText(strN);
        strN.sprintf("%X",ware2);
        ui->data2Ql->setText(strN);
        strN.sprintf("%X",check);
        ui->checkQl->setText(strN);

        ui->isValidQl->setText("是");
        update_data();  //画波形点
    }
    else
    {
        ui->isValidQl->setText("否");
    }
}

//自动数据更新
void Ware::update_data()
{
    int i;
    QVector<QPointF> oldData1 = series[0].pointsVector();  //波形1，前一次数据，以向量的形式获取数据集中的点
    QVector<QPointF> oldData2 = series[1].pointsVector();  //波形2，前一次数据，以向量的形式获取数据集中的点
    QVector<QPointF> data1,data2;
    //double dataY1,dataY2;
    int16_t dataY1,dataY2;

    //获取波形数据
    //dataY1 = 10 * sin(M_PI * count * 4 / 180);   //获取新数据
    //dataY2 = 10 * cos(M_PI * count * 4 / 180);
    dataY1 = ware1;
    dataY2 = ware2;

    count++;

    if(!isStopping)  //判断是否开始波形更新
    {
        //根据波形的值动态改变Y轴范围
        if(dataY1 > maxY)
            maxY = dataY1;
        else if(dataY1 < minY)
            minY = dataY1;
        if(dataY2 > maxY)
            maxY = dataY2;
        else if(dataY2 < minY)
            minY = dataY2;
        chart->axisY()->setRange(minY, maxY);     //设置Y轴范围

        //波形1
        if (oldData1.size() < POINTNUM+1)   //点数小于
        {
            data1 = series[0].pointsVector();
        }
        else
        {
            /* 添加之前老的数据到新的vector中，不复制最前的数据，即每次替换前面的数据
             * 由于这里每次只添加1个数据，所以为1，使用时根据实际情况修改
             */
            for (i = 1; i < oldData1.size(); ++i)
            {
                data1.append(QPointF(i - 1 , oldData1.at(i).y()));    //旧数据左移1个
            }
        }

        //波形2
        if (oldData2.size() < POINTNUM+1)   //点数小于
        {
            data2 = series[1].pointsVector();
        }
        else
        {
            for (i = 1; i < oldData1.size(); ++i)
            {
                data2.append(QPointF(i - 1 , oldData2.at(i).y()));    //旧数据左移1个
            }
        }

        qint64 size1 = data1.size();
        qint64 size2 = data2.size();

        /*这里表示插入新的数据，因为每次只插入1个，这里为i < 1,但为了后面方便插入多个数据，先这样写*/
        for(i = 0; i < 1; ++i)  //波形1
        {
            data1.append(QPointF(i + size1, dataY1));   //插入新的数据
        }
        for(i = 0; i < 1; ++i)  //波形2
        {
            data2.append(QPointF(i + size2, dataY2));   //插入新的数据
        }

        series[0].replace(data1);  //替换显示
        series[1].replace(data2);  //替换显示

        set_num_on_qcheckBox(ui->ware1Cbox,"波形1：",dataY1);
        set_num_on_qcheckBox(ui->ware2Cbox,"波形2：",dataY2);
    }
}

/************************鼠标滚轮事件************************/
void Ware::wheelEvent(QWheelEvent *event)
{
    if (event->delta() > 0)
    {
        chart->zoom(1.1);       //放大
    } else
    {
        chart->zoom(10.0/11);   //缩小
    }

    QWidget::wheelEvent(event);
}

/************************波形数据光标槽函数************************/
void Ware::tipSlot(QPointF position, bool isHovering)
{
    if (tip == nullptr)
        tip = new Callout(chart);

    if (isHovering)     //触发鼠标悬停信号
    {
        tip->setText(QString("X: %1 \nY: %2 ").arg(position.x()).arg(position.y()));
        tip->setAnchor(position);
        tip->setZValue(11);
        tip->updateGeometry();
        tip->show();
    }
    else
    {
        tip->hide();        //光标信息隐藏
    }
}

/************************波形主题切换键槽函数************************/
void Ware::on_themeChooseQcb_currentIndexChanged()
{
    if(ui->themeChooseQcb->currentText() == "维多利亚白")
    {
        chart->setTheme(QChart::ChartThemeLight); //设置系统主题
        chart->setTitleFont(QFont("微软雅黑",15, QFont::Black, false)); //设置标题字体
        chart->setTitle("电压监测波形图");          //设置标题
        chart->legend()->show();                  //显示图例

        //波形1
        QPen pen1(Qt::darkRed);              //设置画笔颜色
        pen1.setWidth(2);                    //设置线宽
        series[0].setPen(pen1);              //设置画笔

        //波形2
        QPen pen2(Qt::darkBlue);             //设置画笔颜色
        pen2.setWidth(2);                    //设置线宽
        series[1].setPen(pen2);              //设置画笔

        chart->axisX()->setTitleFont(QFont("Microsoft YaHei", 10, QFont::Normal, true));
        chart->axisY()->setTitleFont(QFont("Microsoft YaHei", 10, QFont::Normal, true));
    }
    else if(ui->themeChooseQcb->currentText() == "五彩斑斓黑")
    {
        chart->setTheme(QChart::ChartThemeDark); //设置系统主题
        chart->setTitleFont(QFont("微软雅黑",15, QFont::Black, false)); //设置标题字体
        chart->setTitle("电压监测波形图");          //设置标题
        chart->legend()->show();                  //隐藏图例

        //波形1
        QPen pen1(Qt::yellow);             //设置画笔颜色
        pen1.setWidth(2);                  //设置线宽
        series[0].setPen(pen1);            //设置画笔

        //波形2
        QPen pen2(Qt::cyan);               //设置画笔颜色
        pen2.setWidth(2);                  //设置线宽
        series[1].setPen(pen2);            //设置画笔

        chart->axisX()->setTitleFont(QFont("Microsoft YaHei", 10, QFont::Normal, true));
        chart->axisY()->setTitleFont(QFont("Microsoft YaHei", 10, QFont::Normal, true));
    }
    else if(ui->themeChooseQcb->currentText() == "花里胡哨蓝")
    {
        chart->setTheme(QChart::ChartThemeBlueCerulean); //设置系统主题
        chart->setTitleFont(QFont("微软雅黑",15, QFont::Black, false)); //设置标题字体
        chart->setTitle("电压监测波形图");          //设置标题
        chart->legend()->show();                  //隐藏图例

        //波形1
        QPen pen1(Qt::magenta);            //设置画笔颜色
        pen1.setWidth(2);                  //设置线宽
        series[0].setPen(pen1);            //设置画笔

        //波形2
        QPen pen2(Qt::green);              //设置画笔颜色
        pen2.setWidth(2);                  //设置线宽
        series[1].setPen(pen2);            //设置画笔

        chart->axisX()->setTitleFont(QFont("Microsoft YaHei", 10, QFont::Normal, true));
        chart->axisY()->setTitleFont(QFont("Microsoft YaHei", 10, QFont::Normal, true));
    }

    //波形显示关闭
    if(isShowWare1 == false)
    {
        QPen pen1(Qt::transparent);        //设置画笔颜色透明
        pen1.setWidth(2);                  //设置线宽
        series[0].setPen(pen1);            //设置画笔
    }

    if(isShowWare2 == false)
    {
        QPen pen2(Qt::transparent);        //设置画笔颜色
        pen2.setWidth(2);                  //设置线宽
        series[1].setPen(pen2);            //设置画笔
    }
}

/************************暂停开始按键槽信号************************/
void Ware::on_startOrStopBt_clicked()
{
    if (!isStopping)
    {
        ui->startOrStopBt->setText("开始");
    }
    else
    {
        ui->startOrStopBt->setText("暂停");
    }
    isStopping = !isStopping;
}

/************************波形清空键槽函数************************/
void Ware::on_clearBt_clicked()
{
    series[0].clear();
    series[1].clear();
    minY = -5;
    maxY = 5;
    chart->axisY()->setRange(minY, maxY);     //设置Y轴范围

    head = 0;
    address = 0;
    length = 0;
    ware1 = 0;
    ware2 = 0;
    check = 0;
}

/************************波形复位按键槽信号************************/
void Ware::on_resetBt_clicked()
{
    chart->zoomReset(); //复原成缩放前的大小
}

/************************波形1是否显示槽函数************************/
void Ware::on_ware1Cbox_stateChanged()
{
    isShowWare1 = !isShowWare1;
    on_themeChooseQcb_currentIndexChanged();
}

/************************波形2是否显示槽函数************************/
void Ware::on_ware2Cbox_stateChanged()
{
    isShowWare2 = !isShowWare2;
    on_themeChooseQcb_currentIndexChanged();
}

Ware::~Ware()
{
    delete ui;
}
