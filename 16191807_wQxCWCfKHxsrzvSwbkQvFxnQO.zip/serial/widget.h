#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtSerialPort>
#include "QString"
#include "ui_widget.h"
#include "ware.h"

#include "QTimer"
#include "QTime"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
    QSerialPort *serialPort;    //添加一个对象

    //发送和接收计数
    long sendNum=0, recvNum=0;
    void set_num_on_label(QLabel *lbl, QString strS, long num);

    //定时器
    QTimer timer;
    QTime  time;

    Ware *wa;   //波形绘制界面

    //串口是否连接
    bool isSerialConnect=false;

private slots:
    void on_openBt_clicked();

    void on_closeBt_clicked();

    void serialPortReadyRead_Slot();    //需要在此手动声明槽函数

    void on_sendBt_clicked();

    void on_clearBt_clicked();

    void on_wareBt_clicked();

    void on_searchBt_clicked();

    void on_is16SendQch_stateChanged();

    void on_is16RecvQch_stateChanged();

    void on_timeSendQch_stateChanged();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
