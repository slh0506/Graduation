/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *layoutWidget;
    QGridLayout *gridLayout_17;
    QGridLayout *gridLayout_6;
    QFrame *frame_2;
    QGridLayout *gridLayout_8;
    QGridLayout *gridLayout;
    QLabel *label_2;
    QComboBox *dataCb;
    QLabel *label_4;
    QLabel *label_5;
    QComboBox *checkCb;
    QComboBox *serialCb;
    QComboBox *stopCb;
    QComboBox *baundrateCb;
    QLabel *label_6;
    QLabel *label;
    QComboBox *streamCb;
    QLabel *label_3;
    QGridLayout *gridLayout_5;
    QGridLayout *gridLayout_4;
    QLabel *label_9;
    QLineEdit *lineEdit;
    QGridLayout *gridLayout_3;
    QPushButton *openBt;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *closeBt;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *clearBt;
    QPushButton *wareBt;
    QPushButton *sendBt;
    QSpacerItem *horizontalSpacer;
    QPushButton *searchBt;
    QSpacerItem *horizontalSpacer_11;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QLabel *label_7;
    QLabel *label_8;
    QFrame *frame;
    QGridLayout *gridLayout_7;
    QLabel *label_10;
    QLineEdit *timeSendQl;
    QCheckBox *is16RecvQch;
    QCheckBox *timeSendQch;
    QLabel *recvLbl;
    QLabel *sendLbl;
    QLabel *label_11;
    QSpacerItem *horizontalSpacer_6;
    QCheckBox *is16SendQch;
    QPlainTextEdit *plainTextEdit;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(902, 500);
        Widget->setMinimumSize(QSize(902, 500));
        Widget->setMaximumSize(QSize(902, 500));
        layoutWidget = new QWidget(Widget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(6, 10, 891, 486));
        gridLayout_17 = new QGridLayout(layoutWidget);
        gridLayout_17->setSpacing(6);
        gridLayout_17->setContentsMargins(11, 11, 11, 11);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        gridLayout_17->setContentsMargins(0, 0, 0, 0);
        gridLayout_6 = new QGridLayout();
        gridLayout_6->setSpacing(6);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        frame_2 = new QFrame(layoutWidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::Box);
        frame_2->setFrameShadow(QFrame::Sunken);
        gridLayout_8 = new QGridLayout(frame_2);
        gridLayout_8->setSpacing(0);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(2, 2, 2, 2);
        label_2 = new QLabel(frame_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        dataCb = new QComboBox(frame_2);
        dataCb->addItem(QString());
        dataCb->addItem(QString());
        dataCb->addItem(QString());
        dataCb->addItem(QString());
        dataCb->setObjectName(QString::fromUtf8("dataCb"));

        gridLayout->addWidget(dataCb, 2, 1, 1, 1);

        label_4 = new QLabel(frame_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        label_5 = new QLabel(frame_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 4, 0, 1, 1);

        checkCb = new QComboBox(frame_2);
        checkCb->addItem(QString());
        checkCb->setObjectName(QString::fromUtf8("checkCb"));

        gridLayout->addWidget(checkCb, 4, 1, 1, 1);

        serialCb = new QComboBox(frame_2);
        serialCb->setObjectName(QString::fromUtf8("serialCb"));

        gridLayout->addWidget(serialCb, 0, 1, 1, 1);

        stopCb = new QComboBox(frame_2);
        stopCb->addItem(QString());
        stopCb->addItem(QString());
        stopCb->addItem(QString());
        stopCb->setObjectName(QString::fromUtf8("stopCb"));

        gridLayout->addWidget(stopCb, 3, 1, 1, 1);

        baundrateCb = new QComboBox(frame_2);
        baundrateCb->addItem(QString());
        baundrateCb->addItem(QString());
        baundrateCb->addItem(QString());
        baundrateCb->setObjectName(QString::fromUtf8("baundrateCb"));

        gridLayout->addWidget(baundrateCb, 1, 1, 1, 1);

        label_6 = new QLabel(frame_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 5, 0, 1, 1);

        label = new QLabel(frame_2);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        streamCb = new QComboBox(frame_2);
        streamCb->addItem(QString());
        streamCb->setObjectName(QString::fromUtf8("streamCb"));

        gridLayout->addWidget(streamCb, 5, 1, 1, 1);

        label_3 = new QLabel(frame_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);


        gridLayout_8->addLayout(gridLayout, 0, 0, 1, 1);


        gridLayout_6->addWidget(frame_2, 0, 0, 1, 1);

        gridLayout_5 = new QGridLayout();
        gridLayout_5->setSpacing(6);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_4 = new QGridLayout();
        gridLayout_4->setSpacing(6);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_4->addWidget(label_9, 0, 0, 1, 1);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        gridLayout_4->addWidget(lineEdit, 0, 1, 1, 1);


        gridLayout_5->addLayout(gridLayout_4, 2, 0, 1, 1);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(6);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        openBt = new QPushButton(layoutWidget);
        openBt->setObjectName(QString::fromUtf8("openBt"));

        gridLayout_3->addWidget(openBt, 0, 2, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(13, 25, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_4, 0, 9, 1, 1);

        closeBt = new QPushButton(layoutWidget);
        closeBt->setObjectName(QString::fromUtf8("closeBt"));
        closeBt->setEnabled(false);

        gridLayout_3->addWidget(closeBt, 0, 4, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(13, 25, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_2, 0, 5, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(13, 25, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_3, 0, 7, 1, 1);

        clearBt = new QPushButton(layoutWidget);
        clearBt->setObjectName(QString::fromUtf8("clearBt"));

        gridLayout_3->addWidget(clearBt, 0, 8, 1, 1);

        wareBt = new QPushButton(layoutWidget);
        wareBt->setObjectName(QString::fromUtf8("wareBt"));
        wareBt->setEnabled(true);

        gridLayout_3->addWidget(wareBt, 0, 10, 1, 1);

        sendBt = new QPushButton(layoutWidget);
        sendBt->setObjectName(QString::fromUtf8("sendBt"));
        sendBt->setEnabled(false);

        gridLayout_3->addWidget(sendBt, 0, 6, 1, 1);

        horizontalSpacer = new QSpacerItem(13, 25, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer, 0, 3, 1, 1);

        searchBt = new QPushButton(layoutWidget);
        searchBt->setObjectName(QString::fromUtf8("searchBt"));

        gridLayout_3->addWidget(searchBt, 0, 0, 1, 1);

        horizontalSpacer_11 = new QSpacerItem(13, 25, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_11, 0, 1, 1, 1);


        gridLayout_5->addLayout(gridLayout_3, 1, 0, 1, 1);

        groupBox = new QGroupBox(layoutWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMinimumSize(QSize(709, 100));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\215\216\346\226\207\345\275\251\344\272\221"));
        font.setPointSize(15);
        font.setBold(true);
        font.setWeight(75);
        groupBox->setFont(font);
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\271\274\345\234\206"));
        font1.setPointSize(9);
        font1.setBold(false);
        font1.setWeight(50);
        label_7->setFont(font1);
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_7, 0, 0, 1, 1);

        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font1);
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_8, 1, 0, 1, 1);


        gridLayout_5->addWidget(groupBox, 0, 0, 1, 1);


        gridLayout_6->addLayout(gridLayout_5, 0, 1, 1, 1);


        gridLayout_17->addLayout(gridLayout_6, 1, 0, 1, 1);

        frame = new QFrame(layoutWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setFrameShape(QFrame::Box);
        frame->setFrameShadow(QFrame::Sunken);
        gridLayout_7 = new QGridLayout(frame);
        gridLayout_7->setSpacing(0);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        gridLayout_7->setContentsMargins(1, 1, 1, 1);
        label_10 = new QLabel(frame);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setFrameShape(QFrame::Box);
        label_10->setFrameShadow(QFrame::Sunken);

        gridLayout_7->addWidget(label_10, 0, 3, 1, 1);

        timeSendQl = new QLineEdit(frame);
        timeSendQl->setObjectName(QString::fromUtf8("timeSendQl"));
        timeSendQl->setMaximumSize(QSize(51, 16777215));
        timeSendQl->setFrame(true);
        timeSendQl->setEchoMode(QLineEdit::Normal);

        gridLayout_7->addWidget(timeSendQl, 0, 4, 1, 1);

        is16RecvQch = new QCheckBox(frame);
        is16RecvQch->setObjectName(QString::fromUtf8("is16RecvQch"));
        is16RecvQch->setTabletTracking(false);
        is16RecvQch->setTristate(false);

        gridLayout_7->addWidget(is16RecvQch, 0, 1, 1, 1);

        timeSendQch = new QCheckBox(frame);
        timeSendQch->setObjectName(QString::fromUtf8("timeSendQch"));
        timeSendQch->setTristate(false);

        gridLayout_7->addWidget(timeSendQch, 0, 2, 1, 1);

        recvLbl = new QLabel(frame);
        recvLbl->setObjectName(QString::fromUtf8("recvLbl"));
        recvLbl->setFrameShape(QFrame::Box);
        recvLbl->setFrameShadow(QFrame::Sunken);

        gridLayout_7->addWidget(recvLbl, 0, 8, 1, 1);

        sendLbl = new QLabel(frame);
        sendLbl->setObjectName(QString::fromUtf8("sendLbl"));
        sendLbl->setFrameShape(QFrame::Box);
        sendLbl->setFrameShadow(QFrame::Sunken);

        gridLayout_7->addWidget(sendLbl, 0, 7, 1, 1);

        label_11 = new QLabel(frame);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setFrameShape(QFrame::Box);
        label_11->setFrameShadow(QFrame::Sunken);

        gridLayout_7->addWidget(label_11, 0, 5, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(252, 14, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_7->addItem(horizontalSpacer_6, 0, 6, 1, 1);

        is16SendQch = new QCheckBox(frame);
        is16SendQch->setObjectName(QString::fromUtf8("is16SendQch"));
        is16SendQch->setEnabled(true);
        is16SendQch->setChecked(false);
        is16SendQch->setTristate(false);

        gridLayout_7->addWidget(is16SendQch, 0, 0, 1, 1);


        gridLayout_17->addWidget(frame, 2, 0, 1, 1);

        plainTextEdit = new QPlainTextEdit(layoutWidget);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setMinimumSize(QSize(879, 272));
        plainTextEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        plainTextEdit->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        plainTextEdit->setTabChangesFocus(false);
        plainTextEdit->setLineWrapMode(QPlainTextEdit::WidgetWidth);
        plainTextEdit->setReadOnly(true);
        plainTextEdit->setOverwriteMode(false);
        plainTextEdit->setBackgroundVisible(false);

        gridLayout_17->addWidget(plainTextEdit, 0, 0, 1, 1);


        retranslateUi(Widget);

        dataCb->setCurrentIndex(3);
        baundrateCb->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        label_2->setText(QApplication::translate("Widget", "\346\263\242\347\211\271\347\216\207\357\274\232", nullptr));
        dataCb->setItemText(0, QApplication::translate("Widget", "5", nullptr));
        dataCb->setItemText(1, QApplication::translate("Widget", "6", nullptr));
        dataCb->setItemText(2, QApplication::translate("Widget", "7", nullptr));
        dataCb->setItemText(3, QApplication::translate("Widget", "8", nullptr));

        label_4->setText(QApplication::translate("Widget", "\345\201\234\346\255\242\344\275\215\357\274\232", nullptr));
        label_5->setText(QApplication::translate("Widget", "\346\240\241\351\252\214\344\275\215\357\274\232", nullptr));
        checkCb->setItemText(0, QApplication::translate("Widget", "\346\227\240", nullptr));

        stopCb->setItemText(0, QApplication::translate("Widget", "1", nullptr));
        stopCb->setItemText(1, QApplication::translate("Widget", "1.5", nullptr));
        stopCb->setItemText(2, QApplication::translate("Widget", "2", nullptr));

        baundrateCb->setItemText(0, QApplication::translate("Widget", "4800", nullptr));
        baundrateCb->setItemText(1, QApplication::translate("Widget", "9600", nullptr));
        baundrateCb->setItemText(2, QApplication::translate("Widget", "115200", nullptr));

        label_6->setText(QApplication::translate("Widget", "\346\265\201\346\216\247\357\274\232", nullptr));
        label->setText(QApplication::translate("Widget", "\344\270\262\345\217\243\345\217\267\357\274\232", nullptr));
        streamCb->setItemText(0, QApplication::translate("Widget", "\346\232\202\344\270\215\344\275\277\347\224\250", nullptr));

        label_3->setText(QApplication::translate("Widget", "\346\225\260\346\215\256\344\275\215\357\274\232", nullptr));
        label_9->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\346\241\206\357\274\232", nullptr));
        lineEdit->setText(QString());
        openBt->setText(QApplication::translate("Widget", "\346\211\223\345\274\200\344\270\262\345\217\243", nullptr));
        closeBt->setText(QApplication::translate("Widget", "\345\205\263\351\227\255\344\270\262\345\217\243", nullptr));
        clearBt->setText(QApplication::translate("Widget", "\346\270\205\347\251\272\346\225\260\346\215\256", nullptr));
        wareBt->setText(QApplication::translate("Widget", "\346\263\242\345\275\242", nullptr));
        sendBt->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\346\225\260\346\215\256", nullptr));
        searchBt->setText(QApplication::translate("Widget", "\346\220\234\347\264\242\344\270\262\345\217\243", nullptr));
        groupBox->setTitle(QApplication::translate("Widget", "\344\270\262\345\217\243\345\212\251\346\211\213", nullptr));
        label_7->setText(QApplication::translate("Widget", " \347\211\210\346\234\254\357\274\232v1.2", nullptr));
        label_8->setText(QApplication::translate("Widget", "\345\210\266\344\275\234\344\272\272\357\274\232\351\202\223\344\274\237\344\270\232", nullptr));
        label_10->setText(QApplication::translate("Widget", "\345\221\250\346\234\237:", nullptr));
        timeSendQl->setText(QApplication::translate("Widget", "0", nullptr));
        is16RecvQch->setText(QApplication::translate("Widget", "\345\215\201\345\205\255\350\277\233\345\210\266\346\216\245\346\224\266", nullptr));
        timeSendQch->setText(QApplication::translate("Widget", "\345\256\232\346\227\266\345\217\221\351\200\201", nullptr));
        recvLbl->setText(QApplication::translate("Widget", "R:      0", nullptr));
        sendLbl->setText(QApplication::translate("Widget", "S:      0", nullptr));
        label_11->setText(QApplication::translate("Widget", "ms", nullptr));
        is16SendQch->setText(QApplication::translate("Widget", "\345\215\201\345\205\255\350\277\233\345\210\266\345\217\221\351\200\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
