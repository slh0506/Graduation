/********************************************************************************
** Form generated from reading UI file 'ware.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WARE_H
#define UI_WARE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Ware
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *wareQbl;
    QFrame *frame_3;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_4;
    QFrame *frame_2;
    QGridLayout *gridLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QCheckBox *ware1Cbox;
    QCheckBox *ware2Cbox;
    QLabel *label_3;
    QFrame *frame_4;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_14;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer_6;
    QLabel *label_13;
    QLabel *label_9;
    QLineEdit *headQl;
    QLabel *label_8;
    QLabel *label_11;
    QLineEdit *isValidQl;
    QLabel *label_15;
    QLineEdit *checkQl;
    QSpacerItem *horizontalSpacer_8;
    QLineEdit *lengthQl;
    QLabel *label_12;
    QSpacerItem *horizontalSpacer_3;
    QLineEdit *addressQl;
    QLineEdit *data1Ql;
    QLabel *label_6;
    QLabel *label_10;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *horizontalSpacer_7;
    QLineEdit *data2Ql;
    QLabel *label_5;
    QLabel *label_7;
    QLabel *label_16;
    QFrame *frame;
    QGridLayout *gridLayout;
    QLabel *label;
    QComboBox *themeChooseQcb;
    QPushButton *resetBt;
    QPushButton *startOrStopBt;
    QPushButton *clearBt;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *Ware)
    {
        if (Ware->objectName().isEmpty())
            Ware->setObjectName(QString::fromUtf8("Ware"));
        Ware->resize(1100, 610);
        Ware->setMinimumSize(QSize(1100, 610));
        Ware->setMaximumSize(QSize(1100, 610));
        horizontalLayoutWidget = new QWidget(Ware);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(0, 0, 1101, 511));
        wareQbl = new QHBoxLayout(horizontalLayoutWidget);
        wareQbl->setObjectName(QString::fromUtf8("wareQbl"));
        wareQbl->setContentsMargins(0, 0, 0, 0);
        frame_3 = new QFrame(horizontalLayoutWidget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);

        wareQbl->addWidget(frame_3);

        layoutWidget = new QWidget(Ware);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 511, 1081, 98));
        gridLayout_4 = new QGridLayout(layoutWidget);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        frame_2 = new QFrame(layoutWidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::Box);
        frame_2->setFrameShadow(QFrame::Sunken);
        gridLayout_2 = new QGridLayout(frame_2);
        gridLayout_2->setSpacing(0);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(2, 0, 2, 0);
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_2, 0, 3, 1, 1);

        ware1Cbox = new QCheckBox(frame_2);
        ware1Cbox->setObjectName(QString::fromUtf8("ware1Cbox"));
        ware1Cbox->setEnabled(true);
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setBold(false);
        font.setWeight(50);
        ware1Cbox->setFont(font);
        ware1Cbox->setAutoFillBackground(false);
        ware1Cbox->setChecked(true);

        gridLayout_2->addWidget(ware1Cbox, 0, 0, 1, 1);

        ware2Cbox = new QCheckBox(frame_2);
        ware2Cbox->setObjectName(QString::fromUtf8("ware2Cbox"));
        ware2Cbox->setFont(font);
        ware2Cbox->setChecked(true);

        gridLayout_2->addWidget(ware2Cbox, 0, 2, 1, 1);

        label_3 = new QLabel(frame_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_2->addWidget(label_3, 0, 1, 1, 1);


        gridLayout_4->addWidget(frame_2, 0, 0, 1, 1);

        frame_4 = new QFrame(layoutWidget);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setFrameShape(QFrame::Box);
        frame_4->setFrameShadow(QFrame::Sunken);
        gridLayout_3 = new QGridLayout(frame_4);
        gridLayout_3->setSpacing(0);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(2, 0, 2, 1);
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_4, 0, 7, 1, 1);

        label_14 = new QLabel(frame_4);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setMinimumSize(QSize(20, 0));

        gridLayout_3->addWidget(label_14, 0, 13, 1, 1);

        label_4 = new QLabel(frame_4);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMaximumSize(QSize(75, 16777215));

        gridLayout_3->addWidget(label_4, 0, 4, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_6, 0, 15, 1, 1);

        label_13 = new QLabel(frame_4);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setMinimumSize(QSize(20, 0));

        gridLayout_3->addWidget(label_13, 0, 9, 1, 1);

        label_9 = new QLabel(frame_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setMaximumSize(QSize(60, 16777215));

        gridLayout_3->addWidget(label_9, 0, 20, 1, 1);

        headQl = new QLineEdit(frame_4);
        headQl->setObjectName(QString::fromUtf8("headQl"));
        headQl->setMaximumSize(QSize(25, 16777215));
        headQl->setAlignment(Qt::AlignCenter);
        headQl->setReadOnly(true);

        gridLayout_3->addWidget(headQl, 0, 2, 1, 1);

        label_8 = new QLabel(frame_4);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setMaximumSize(QSize(50, 16777215));

        gridLayout_3->addWidget(label_8, 0, 16, 1, 1);

        label_11 = new QLabel(frame_4);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setMinimumSize(QSize(20, 0));

        gridLayout_3->addWidget(label_11, 0, 1, 1, 1);

        isValidQl = new QLineEdit(frame_4);
        isValidQl->setObjectName(QString::fromUtf8("isEffectiveQl"));
        isValidQl->setMaximumSize(QSize(40, 16777215));
        isValidQl->setAlignment(Qt::AlignCenter);
        isValidQl->setReadOnly(true);

        gridLayout_3->addWidget(isValidQl, 0, 25, 1, 1);

        label_15 = new QLabel(frame_4);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setMinimumSize(QSize(20, 0));

        gridLayout_3->addWidget(label_15, 0, 17, 1, 1);

        checkQl = new QLineEdit(frame_4);
        checkQl->setObjectName(QString::fromUtf8("checkQl"));
        checkQl->setMaximumSize(QSize(25, 16777215));
        checkQl->setAlignment(Qt::AlignCenter);
        checkQl->setReadOnly(true);

        gridLayout_3->addWidget(checkQl, 0, 22, 1, 1);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_8, 0, 23, 1, 1);

        lengthQl = new QLineEdit(frame_4);
        lengthQl->setObjectName(QString::fromUtf8("lengthQl"));
        lengthQl->setMaximumSize(QSize(40, 16777215));
        lengthQl->setLayoutDirection(Qt::LeftToRight);
        lengthQl->setCursorPosition(0);
        lengthQl->setAlignment(Qt::AlignCenter);
        lengthQl->setReadOnly(true);

        gridLayout_3->addWidget(lengthQl, 0, 10, 1, 1);

        label_12 = new QLabel(frame_4);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setMinimumSize(QSize(20, 0));

        gridLayout_3->addWidget(label_12, 0, 5, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_3, 0, 3, 1, 1);

        addressQl = new QLineEdit(frame_4);
        addressQl->setObjectName(QString::fromUtf8("addressQl"));
        addressQl->setMaximumSize(QSize(25, 16777215));
        addressQl->setAlignment(Qt::AlignCenter);
        addressQl->setReadOnly(true);

        gridLayout_3->addWidget(addressQl, 0, 6, 1, 1);

        data1Ql = new QLineEdit(frame_4);
        data1Ql->setObjectName(QString::fromUtf8("data1Ql"));
        data1Ql->setMaximumSize(QSize(40, 16777215));
        data1Ql->setAlignment(Qt::AlignCenter);
        data1Ql->setReadOnly(true);

        gridLayout_3->addWidget(data1Ql, 0, 14, 1, 1);

        label_6 = new QLabel(frame_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMaximumSize(QSize(75, 16777215));

        gridLayout_3->addWidget(label_6, 0, 8, 1, 1);

        label_10 = new QLabel(frame_4);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setMaximumSize(QSize(405, 16777215));

        gridLayout_3->addWidget(label_10, 0, 24, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_5, 0, 11, 1, 1);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_7, 0, 19, 1, 1);

        data2Ql = new QLineEdit(frame_4);
        data2Ql->setObjectName(QString::fromUtf8("data2Ql"));
        data2Ql->setMaximumSize(QSize(40, 16777215));
        data2Ql->setAlignment(Qt::AlignCenter);
        data2Ql->setReadOnly(true);

        gridLayout_3->addWidget(data2Ql, 0, 18, 1, 1);

        label_5 = new QLabel(frame_4);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMaximumSize(QSize(45, 16777215));

        gridLayout_3->addWidget(label_5, 0, 0, 1, 1);

        label_7 = new QLabel(frame_4);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setMaximumSize(QSize(50, 16777215));

        gridLayout_3->addWidget(label_7, 0, 12, 1, 1);

        label_16 = new QLabel(frame_4);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setMinimumSize(QSize(20, 0));

        gridLayout_3->addWidget(label_16, 0, 21, 1, 1);


        gridLayout_4->addWidget(frame_4, 1, 0, 1, 1);

        frame = new QFrame(layoutWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setFrameShape(QFrame::Box);
        frame->setFrameShadow(QFrame::Sunken);
        gridLayout = new QGridLayout(frame);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFrameShape(QFrame::Box);
        label->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(label, 0, 6, 1, 1);

        themeChooseQcb = new QComboBox(frame);
        themeChooseQcb->addItem(QString());
        themeChooseQcb->addItem(QString());
        themeChooseQcb->addItem(QString());
        themeChooseQcb->setObjectName(QString::fromUtf8("themeChooseQcb"));

        gridLayout->addWidget(themeChooseQcb, 0, 5, 1, 1);

        resetBt = new QPushButton(frame);
        resetBt->setObjectName(QString::fromUtf8("resetBt"));

        gridLayout->addWidget(resetBt, 0, 1, 1, 1);

        startOrStopBt = new QPushButton(frame);
        startOrStopBt->setObjectName(QString::fromUtf8("startOrStopBt"));

        gridLayout->addWidget(startOrStopBt, 0, 0, 1, 1);

        clearBt = new QPushButton(frame);
        clearBt->setObjectName(QString::fromUtf8("clearBt"));

        gridLayout->addWidget(clearBt, 0, 2, 1, 1);

        label_2 = new QLabel(frame);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 0, 4, 1, 1);

        horizontalSpacer = new QSpacerItem(472, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 3, 1, 1);


        gridLayout_4->addWidget(frame, 2, 0, 1, 1);


        retranslateUi(Ware);

        QMetaObject::connectSlotsByName(Ware);
    } // setupUi

    void retranslateUi(QWidget *Ware)
    {
        Ware->setWindowTitle(QApplication::translate("Ware", "Form", nullptr));
        ware1Cbox->setText(QApplication::translate("Ware", "\346\263\242\345\275\2421\357\274\232     0", nullptr));
        ware2Cbox->setText(QApplication::translate("Ware", "\346\263\242\345\275\2422\357\274\232     0", nullptr));
        label_3->setText(QString());
        label_14->setText(QApplication::translate("Ware", "0x", nullptr));
        label_4->setText(QApplication::translate("Ware", "\347\233\256\346\240\207\345\234\260\345\235\200\357\274\232", nullptr));
        label_13->setText(QApplication::translate("Ware", "0x", nullptr));
        label_9->setText(QApplication::translate("Ware", "\346\240\241\351\252\214\347\240\201\357\274\232", nullptr));
        headQl->setText(QString());
        label_8->setText(QApplication::translate("Ware", "\346\225\260\346\215\2562\357\274\232", nullptr));
        label_11->setText(QApplication::translate("Ware", "0x", nullptr));
        isValidQl->setText(QString());
        label_15->setText(QApplication::translate("Ware", "0x", nullptr));
        checkQl->setText(QString());
        lengthQl->setText(QString());
        label_12->setText(QApplication::translate("Ware", "0x", nullptr));
        label_6->setText(QApplication::translate("Ware", "\346\225\260\346\215\256\351\225\277\345\272\246\357\274\232", nullptr));
        label_10->setText(QApplication::translate("Ware", "\346\225\260\346\215\256\346\230\257\345\220\246\346\234\211\346\225\210\357\274\232", nullptr));
        label_5->setText(QApplication::translate("Ware", "\345\270\247\345\244\264\357\274\232", nullptr));
        label_7->setText(QApplication::translate("Ware", "\346\225\260\346\215\2561\357\274\232", nullptr));
        label_16->setText(QApplication::translate("Ware", "0x", nullptr));
        label->setText(QApplication::translate("Ware", "\351\207\207\346\240\267\345\221\250\346\234\237\357\274\232     ms", nullptr));
        themeChooseQcb->setItemText(0, QApplication::translate("Ware", "\347\273\264\345\244\232\345\210\251\344\272\232\347\231\275", nullptr));
        themeChooseQcb->setItemText(1, QApplication::translate("Ware", "\344\272\224\345\275\251\346\226\221\346\226\223\351\273\221", nullptr));
        themeChooseQcb->setItemText(2, QApplication::translate("Ware", "\350\212\261\351\207\214\350\203\241\345\223\250\350\223\235", nullptr));

        resetBt->setText(QApplication::translate("Ware", "\345\244\215\344\275\215", nullptr));
        startOrStopBt->setText(QApplication::translate("Ware", "\346\232\202\345\201\234", nullptr));
        clearBt->setText(QApplication::translate("Ware", "\346\270\205\347\251\272", nullptr));
        label_2->setText(QApplication::translate("Ware", "\344\270\273\351\242\230\351\200\211\346\213\251\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Ware: public Ui_Ware {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WARE_H
